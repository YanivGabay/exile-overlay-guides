import type { Fragments, GameData, RouteData } from "../types.js";
import { parseFragments } from "./fragment/index.js";
import { type Pattern, matchPatterns } from "./patterns.js";
import { ScopedLogger } from "./scoped-logger.js";

const DEFAULT_SECTION_NAME = "Default";

export function getRouteFiles(routeSources: string[]) {
  const routeFiles: RouteData.RouteFile[] = [];
  for (const routeSource of routeSources) {
    const routeLines = routeSource.split(/\r\n|\r|\n/g);

    for (let lineIndex = 0; lineIndex < routeLines.length; lineIndex++) {
      const line = routeLines[lineIndex];

      const sectionRegex = /^ *#section *(.*)/g;
      const sectionMatch = sectionRegex.exec(line);
      if (sectionMatch) {
        const sectionName = sectionMatch[1] || DEFAULT_SECTION_NAME;

        routeFiles.push({
          name: sectionName,
          contents: `#section ${sectionName}`,
        });

        continue;
      }

      if (routeFiles.length == 0) {
        routeFiles.push({
          name: DEFAULT_SECTION_NAME,
          contents: `#section ${DEFAULT_SECTION_NAME}`,
        });
      }

      const workingFile = routeFiles[routeFiles.length - 1];
      workingFile.contents += `\n${line}`;
    }
  }

  return routeFiles;
}

export function buildRouteSource(routeFiles: RouteData.RouteFile[]) {
  return routeFiles.map((x) => x.contents).join("\n");
}

export interface RouteState {
  data: GameData.Bundle;
  implicitWaypoints: Set<GameData.Area["id"]>;
  explicitWaypoints: Set<GameData.Area["id"]>;
  usedWaypoints: Set<GameData.Area["id"]>;
  craftingAreas: Set<GameData.Area["id"]>;
  currentAreaId: GameData.Area["id"];
  lastTownAreaId: GameData.Area["id"];
  portalAreaId: GameData.Area["id"] | null;
  preprocessorDefinitions: Set<string>;
}

interface ParseContext {
  state: RouteState;
  conditionalStack: boolean[];
  logger: ScopedLogger;
  push: (fragments: Fragments.AnyFragment[], isSubstep: boolean) => void;
}

const ROUTE_PATTERNS: Pattern<ParseContext>[] = [
  // endif
  {
    regex: /^( *)#endif/g,
    processor: (match, { conditionalStack, logger }) => {
      const [, padding] = match;

      const value = conditionalStack.pop();
      if (value === undefined) logger.warn("unexpected #endif");

      assertPadding(padding, conditionalStack.length, logger);

      return false;
    },
  },
  // ifdef
  {
    regex: /^( *)#ifdef *(.*)/g,
    processor: (match, { state, conditionalStack, logger }) => {
      const [, padding, value] = match;

      assertPadding(padding, conditionalStack.length, logger);

      if (value)
        conditionalStack.push(state.preprocessorDefinitions.has(value));

      return false;
    },
  },
  // ifndef
  {
    regex: /^( *)#ifndef *(.*)/g,
    processor: (match, { state, conditionalStack, logger }) => {
      const [, padding, value] = match;

      assertPadding(padding, conditionalStack.length, logger);

      if (value)
        conditionalStack.push(!state.preprocessorDefinitions.has(value));

      return false;
    },
  },
  // SubStep
  {
    regex: /^( *)#sub *(.*)/g,
    processor: (match, { state, push, conditionalStack, logger }) => {
      const evaluateLine =
        conditionalStack.length == 0 ||
        conditionalStack[conditionalStack.length - 1];
      if (!evaluateLine) return false;

      const [, padding, value] = match;
      assertPadding(padding, conditionalStack.length + 1, logger);

      const fragments = parseFragments(value.trim(), state, logger);
      push(fragments, true);

      return false;
    },
  },
  // FragmentStep
  {
    regex: /^( *)(.*)/g,
    processor: (match, { state, push, conditionalStack, logger }) => {
      const evaluateLine =
        conditionalStack.length == 0 ||
        conditionalStack[conditionalStack.length - 1];
      if (!evaluateLine) return false;

      const [, padding, value] = match;
      assertPadding(padding, conditionalStack.length, logger);

      const fragments = parseFragments(value.trim(), state, logger);
      push(fragments, false);

      return false;
    },
  },
];

function assertPadding(text: string, depth: number, logger: ScopedLogger) {
  const expectedPadding = depth * 4;

  let actualPadding = 0;
  const match = /^( *)/g.exec(text);
  if (match) actualPadding = match[1].length;

  if (actualPadding !== expectedPadding)
    logger.warn(
      `expected ${expectedPadding} whitespace, found ${actualPadding}`,
    );
}

export function parseRoute(
  routeFiles: RouteData.RouteFile[],
  state: RouteState,
) {
  const logger = new ScopedLogger();

  const route: RouteData.Route = { sections: [], edges: [state.currentAreaId] };

  let prev: { step: RouteData.FragmentStep; area: GameData.Area["id"] } | null =
    null;

  for (const routeFile of routeFiles) {
    const routeLines = routeFile.contents.split(/\r\n|\r|\n/g);

    const section: RouteData.Section = {
      name: routeFile.name,
      steps: [],
    };
    route.sections.push(section);

    logger.pushScope(section.name);

    const context: ParseContext = {
      state,
      conditionalStack: [],
      logger,
      push: (fragments, isSubstep) => {
        if (fragments.length == 0) return;

        const step: RouteData.FragmentStep = {
          type: "fragment_step",
          parts: fragments,
          subSteps: [],
          edgeIndex: null,
        };

        let steps;
        if (isSubstep) {
          if (prev === null) {
            logger.warn("substep expected step");
            return;
          }
          if (prev.step.type !== "fragment_step") {
            logger.warn("substep expected fragment_step");
            return;
          }

          steps = prev.step.subSteps;
        } else {
          if (prev !== null && prev.area !== state.currentAreaId) {
            step.edgeIndex = route.edges.length;
            route.edges.push(state.currentAreaId);
          }

          prev = { step: step, area: state.currentAreaId };
          steps = section.steps;
        }

        steps.push(step);
      },
    };

    for (let lineIndex = 0; lineIndex < routeLines.length; lineIndex++) {
      const line = routeLines[lineIndex];
      if (!line) continue;

      logger.pushScope(`line ${lineIndex + 1}`);
      matchPatterns(line, ROUTE_PATTERNS, context);
      logger.popScope();
    }

    if (context.conditionalStack.length != 0) logger.warn("expected #endif");

    logger.popScope();
  }

  for (const waypoint of state.explicitWaypoints) {
    if (!state.usedWaypoints.has(waypoint)) {
      logger.warn(`unused waypoint ${waypoint}`);
    }
  }

  for (const key in state.data.Areas) {
    const area = state.data.Areas[key];
    if (area.crafting_recipes.length > 0 && !state.craftingAreas.has(area.id))
      logger.warn(
        `missing crafting area ${area.id}, ${area.crafting_recipes.join(", ")}`,
      );
  }

  let firstStep = route.sections[0].steps[0];
  if (firstStep.type === "fragment_step") {
    firstStep.edgeIndex = 0;
  }

  return { route, logs: logger.drain() };
}

export function initializeRouteState(data: GameData.Bundle) {
  const state: RouteState = {
    data,
    implicitWaypoints: new Set(),
    explicitWaypoints: new Set(),
    usedWaypoints: new Set(),
    craftingAreas: new Set(),
    currentAreaId: "1_1_1",
    lastTownAreaId: "1_1_town",
    portalAreaId: null,
    preprocessorDefinitions: new Set(),
  };

  return state;
}
